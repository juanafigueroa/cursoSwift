//: Playground - noun: a place where people can play

import UIKit

//Tarea semana 2
//Rango de números de 0 a 100
//Reglas:
//divisible entre 5 - imprimir numero y #Bingo
//par - imprimir número y #Par
//impar - imprimir número e #Impar
//entre 30 y 40 #Viva Swift!!!

var numeros = 0...100
var resto = 0

for numero in numeros{
    
    //divisible entre 5
    resto = numero % 5
    print ("#\(numero)", terminator:" ")
    if resto == 0{
        print("Bingo", terminator:" ")
    }
    
    //par
    resto = numero % 2
    if resto == 0{
        print("Par", terminator:" ")
    }
    
    //impar
    if resto != 0{
        print("Impar", terminator:" ")
    }
    
    //entre 30 y 40
    if numero >= 30 && numero <= 40{
        print ("Viva Swift!!!", terminator:" ")
    }
    
    //imprime salto de línea
    print("")
    
}
//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Juana Figueroa on 3/27/16.
//  Copyright © 2016 Juana Figueroa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblPaises: UILabel!
    @IBOutlet weak var lblHamburguesa: UILabel!
    
    let colores = Colores()
    let paises = ColeccionDePaises()
    let hamburguesas = ColeccionDeHamburguesas()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func dameUnaHamburguesa() {
        let colorAleatorio = colores.regresaColorAleatorio()
        view.backgroundColor = colorAleatorio
        lblPaises.text = paises.regresaPais()
        lblHamburguesa.text = hamburguesas.obtenHamburguesa()
    }

}


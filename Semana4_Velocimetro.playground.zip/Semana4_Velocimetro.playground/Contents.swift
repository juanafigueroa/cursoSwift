//: Velocimetro

import UIKit

enum Velocidades: Int {
    case Apagado = 0
    case VelocidadBaja = 20
    case VelocidadMedia = 50
    case VelocidadAlta = 120
    
    init (velocidadinicial: Velocidades){
        self = velocidadinicial
    }
    
}

class Auto {
    var Velocidad: Velocidades
    var velocidadEnCadena: String
    
    init(){
        self.Velocidad = .Apagado
        self.velocidadEnCadena = "Apagado"
    }
    
    func cambioDeVelocidad()->(actual : Int, velocidadEnCadena: String){
        switch self.Velocidad {
            case .Apagado:
                self.Velocidad = .VelocidadBaja
                velocidadEnCadena = "Velocidad baja"
            case .VelocidadBaja:
                self.Velocidad = .VelocidadMedia
                velocidadEnCadena = "Velocidad media"
            case .VelocidadMedia:
                self.Velocidad = .VelocidadAlta
                velocidadEnCadena = "Velocidad alta"
            case.VelocidadAlta:
                self.Velocidad = .VelocidadMedia
                velocidadEnCadena = "Velocidad media"
        }
        return (actual: self.Velocidad.rawValue, velocidadEnCadena: self.velocidadEnCadena)
    }
}

var auto = Auto()
print ("\(auto.Velocidad.rawValue), \(auto.velocidadEnCadena)")

for i in 1...20 {
    var tupla = auto.cambioDeVelocidad()
    tupla.actual
    tupla.velocidadEnCadena
    print ("\(tupla.actual), \(tupla.velocidadEnCadena)")
}







